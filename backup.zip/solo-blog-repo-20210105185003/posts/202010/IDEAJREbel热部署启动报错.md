title: IDEA JREbel热部署启动报错
date: '2020-10-24 11:19:36'
updated: '2020-10-24 11:19:36'
tags: [IDEA, JREbel, 报错, 编码]
permalink: /articles/2020/10/24/1603509575767.html
---
问题：C盘目录下user名为中文，或JREbel启动路径含有中文。

解决方法：修改编码。

![](https://b3logfile.com/file/2020/10/solofetchupload1735270807352045453-2c94292d.png)

![](https://b3logfile.com/file/2020/10/solofetchupload3556235891734315555-6bf16d0a.png)

调整“java_opts”即可。value=“

-Dfile.encoding=UTF-8 -Djava.awt.headless=true -Xms2048m -Xmx2048m”
