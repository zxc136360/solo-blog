title: centos下安装python3详细教程
date: '2020-07-29 04:06:52'
updated: '2020-07-29 04:07:41'
tags: [centos, python]
permalink: /articles/2020/07/29/1595966812093.html
---
版权声明：本文为博主原创文章，遵循[ CC 4.0 BY-SA ](http://creativecommons.org/licenses/by-sa/4.0/)版权协议，转载请附上原文出处链接和本声明。

```link
本文链接：https://blog.csdn.net/t8116189520/article/details/81976755
```

centos7 自带有 python，版本是python2.7

接下来我们手动安装python3，并且配置后可以并存使用。

### 1.首先，你要知道系统现在的python的位置在哪儿：

```
[root@root ~]# whereis pythonpython: /usr/bin/python2.7 /usr/bin/python /usr/lib/python2.7 /usr/lib64/python2.7 /etc/python /usr/include/python2.7 /usr/share/man/man1/python.1.gz
```

* 可以知道我们的python在 /usr/bin目录中

```
[root@root ~]# cd /usr/bin/[root@root bin]# ll python*lrwxrwxrwx. 1 root root    7 2月   7 09:30 python -> python2lrwxrwxrwx. 1 root root    9 2月   7 09:30 python2 -> python2.7-rwxr-xr-x. 1 root root 7136 8月   4 2017 python2.7
```

* 可以看到，python指向的是python2，python2指向的是python2.7，因此我们可以装个python3，然后将python指向python3，然后python2指向python2.7，那么两个版本的python就能共存了。

### 2.因为我们要安装python3，所以要先安装相关包，用于下载编译python3：

yum install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gcc make
运行了以上命令以后，就安装了编译python3所用到的相关依赖

### 3.默认的，centos7也没有安装pip，不知道是不是因为我安装软件的时候选择的是最小安装的模式。

```
#运行这个命令添加epel扩展源yum -y install epel-release #安装pipyum install python-pip
```

*

### 4.用pip装wget

```
pip install wget
```

*

### 5.用wget下载python3的源码包

```
wget https://www.python.org/ftp/python/3.6.4/Python-3.6.4.tar.xz
```

*

### 6.编译python3源码包

```
#解压xz -d Python-3.6.4.tar.xztar -xf Python-3.6.4.tar #进入解压后的目录，依次执行下面命令进行手动编译cd Python-3.6.4./configure prefix=/usr/local/python3make && make install # 如果出现can't decompress data; zlib not available这个错误，则需要安装相关库#安装依赖zlib、zlib-develyum install zlib zlibyum install zlib zlib-devel
```

*

如果最后没提示出错，就代表正确安装了，在/usr/local/目录下就会有python3目录

### 7.添加软链接

```
#将原来的链接备份mv /usr/bin/python /usr/bin/python.bak #添加python3的软链接ln -s /usr/local/python3/bin/python3.6 /usr/bin/python #测试是否安装成功了python -V
```

*

### 8.更改yum配置，因为其要用到python2才能执行，否则会导致yum不能正常使用

```
vi /usr/bin/yum把#! /usr/bin/python修改为#! /usr/bin/python2 vi /usr/libexec/urlgrabber-ext-down把#! /usr/bin/python 修改为#! /usr/bin/python2
```

启动python2：

![](https://b3logfile.com/file/2020/07/solofetchupload6186827049292746622-15559097.png)

启动python3：

![](https://b3logfile.com/file/2020/07/solofetchupload7393436022314080131-d5dc819b.png)
